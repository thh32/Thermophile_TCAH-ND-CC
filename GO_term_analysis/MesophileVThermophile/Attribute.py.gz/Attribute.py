input = open('./Thermo_BaseLine_Cleaned.arff',mode='rb')
output = open('./Thermo_BaseLine.arff',mode='wb')

for line in input:
    

    line = line.replace("numeric","{0,1}")
    output.write(line)
