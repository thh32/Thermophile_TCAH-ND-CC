#!/bin/bash

if [ $# -ne 1 ] ; then
if [ $# -ne 2 ] ; then
if [ $# -ne 3 ] ; then
	echo "Usage $0 pvalue
pvalue-after-refinement cutoff"
	echo ""
	echo "      default p-value after refinement will be 0.05 if you"
	echo "      omit these parameters. cutoff defaults to 1."
	exit
fi
fi
fi

if [ $# -eq 1 ] ; then
P1=$1
P2=0.05
CO=1
else
if [ $# -eq 2 ] ; then
P1=$1
P2=$2
CO=1
else
P1=$1
P2=$2
CO=$3
fi
fi


for i in GO:0003674 GO:0008150 GO:0005575 
do

NAME=`grep $i /home/nick/Downloads/go_monthly-termdb-tables/term.txt|cut -f2`
echo "Refinement for $NAME ($i)"

"/usr/local/bin/func_hyper_refin" "/home/nick/Downloads/go_monthly-termdb-tables/term.txt" "/home/nick/Downloads/go_monthly-termdb-tables/graph_path.txt" $i "/home/nick/Downloads/go_monthly-termdb-tables/term2term.txt" "/mnt/74B098E203C39202/Temp/Extremophiles/Upper_Lower/.//tmp/$i-changed" "/mnt/74B098E203C39202/Temp/Extremophiles/Upper_Lower/.//tmp/$i-detected" $P1 $P1 $P2 $P2 $CO > "/mnt/74B098E203C39202/Temp/Extremophiles/Upper_Lower/.//tmp/$i-refin"


echo -e "root_node_name\tnode_name\tnode_id\tsign?\traw_p_underrepresentation_of_variable=1\traw_p_overrepresentation_of_variable=1\tp_underrepresentation_after_refinement\tp_overrepresentation_after_refinement" > "/mnt/74B098E203C39202/Temp/Extremophiles/Upper_Lower/.//refinement-$i-"$P1"_"$P2".txt"

"/usr/local/bin/func_category_groups.pl" "/home/nick/Downloads/go_monthly-termdb-tables/term.txt" < "/mnt/74B098E203C39202/Temp/Extremophiles/Upper_Lower/.//tmp/$i-refin" >> "/mnt/74B098E203C39202/Temp/Extremophiles/Upper_Lower/.//refinement-$i-"$P1"_"$P2".txt"

done

cat << XXX

Refinement done. See results in files:
 - /mnt/74B098E203C39202/Temp/Extremophiles/Upper_Lower/.//refinement-\*-${P1}_${P2}.txt 

XXX

