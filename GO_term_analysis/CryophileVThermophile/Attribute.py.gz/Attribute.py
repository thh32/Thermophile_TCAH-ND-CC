input = open('./Cold_Thermo_Finished.arff',mode='rb')
output = open('./Cold_Thermo.arff',mode='wb')

for line in input:
    

    line = line.replace("numeric","{0,1}")
    output.write(line)
